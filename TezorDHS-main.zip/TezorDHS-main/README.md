**TzField Dashboard Web Project**

```
🚀 Give a Star ⭐️ & Fork to this project ... Happy coding! 🤩`
```

## Install : 

Node install: 16.20.0 or higher version 

npm install on root folder and client folder

npm run dev 👨‍💻

## Features : 

Invoice Management 💰

Inventory Management 🧳

Accounting Management 📈

HR Management 🧑‍🤝‍🧑

Ant Design Framework(AntD) 🐜

Based on Mern Stack (Node.js / Express.js / MongoDb / React.js ) 👨‍💻


### May i can customize IDURAR as Saas and provide it to other users ?

No, you cannot customize IDURAR as a SaaS and provide it to other users , You are not allowed to provide IDURAR software to third parties as a hosted or managed service or as softwase as service (Saas), where the service provides users with access to any substantial set of the features or functionality of this software.

## How To Deploy IDURAR ERP CRM :


The Webinar will be this Wednesday at 1pm GMT.

## Our Sponsors





## Docker Compose for local development

- setup additional env variables, if necessary in the below file

```bash
docker-compose.yml
```

- After the necessary configurations run below command :

```bash
docker-compose up -d
```

This will build the images and bring up the containers for frontend, backend and mongodb.

**_NOTE:_** This docker-compose setup is associated for local development only.

## Contributing



## Show your support

Dont forget to give a ⭐️ to this project ... Happy coding!